package com.pinkyshop.PinkyWebParent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PinkyWebParentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PinkyWebParentApplication.class, args);
	}

}
