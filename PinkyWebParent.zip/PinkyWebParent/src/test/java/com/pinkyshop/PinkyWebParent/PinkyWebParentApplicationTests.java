package com.pinkyshop.PinkyWebParent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PinkyWebParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
